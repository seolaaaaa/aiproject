# 지역별 전문대학 찾기

GitHub 저장소 최상위에 app.py, universities.csv, requirements.txt 세 파일을 올리세요.

Streamlit Community Cloud에서 저장소를 연결하고 Main file path를 `app.py`로 설정한 뒤 Deploy를 누르면 됩니다.

지역을 입력하면 제공된 CSV에서 해당 지역 전문대학을 최대 2곳 표시합니다.
